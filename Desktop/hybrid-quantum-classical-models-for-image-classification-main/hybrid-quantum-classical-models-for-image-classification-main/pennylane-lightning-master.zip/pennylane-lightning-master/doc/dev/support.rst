.. include:: ../../README.rst
  :start-after:	support-start-inclusion-marker-do-not-remove
  :end-before: support-end-inclusion-marker-do-not-remove
