.. include:: ../../README.rst
  :start-after:	docker-start-inclusion-marker-do-not-remove
  :end-before: docker-end-inclusion-marker-do-not-remove
