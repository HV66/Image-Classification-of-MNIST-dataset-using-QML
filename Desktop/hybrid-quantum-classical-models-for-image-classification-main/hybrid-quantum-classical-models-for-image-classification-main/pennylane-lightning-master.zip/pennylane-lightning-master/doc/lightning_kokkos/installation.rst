.. include:: ../../README.rst
  :start-after:	installation_LKokkos-start-inclusion-marker-do-not-remove
  :end-before: installation_LKokkos-end-inclusion-marker-do-not-remove