lightning_tensor
================

.. automodapi:: pennylane_lightning.lightning_tensor
    :no-heading:
    :include-all-objects:

.. raw:: html

        <div style='clear:both'></div>
        </br>

Directly importing the device class:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python3

    from pennylane_lightning.lightning_tensor import LightningTensor

