.. include:: ../../README.rst
  :start-after:	installation_LTensor-start-inclusion-marker-do-not-remove
  :end-before: installation_LTensor-end-inclusion-marker-do-not-remove