.. include:: ../../README.rst
  :start-after:	installation_LGPU-start-inclusion-marker-do-not-remove
  :end-before: installation_LGPU-end-inclusion-marker-do-not-remove