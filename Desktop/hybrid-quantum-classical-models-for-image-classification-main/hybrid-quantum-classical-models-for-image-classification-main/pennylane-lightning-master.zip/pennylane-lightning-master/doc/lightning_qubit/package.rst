lightning_qubit
===============

.. automodapi:: pennylane_lightning.lightning_qubit
    :no-heading:
    :include-all-objects:

.. raw:: html

        <div style='clear:both'></div>
        </br>

Directly importing the device class:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python3

    from pennylane_lightning.lightning_qubit import LightningQubit