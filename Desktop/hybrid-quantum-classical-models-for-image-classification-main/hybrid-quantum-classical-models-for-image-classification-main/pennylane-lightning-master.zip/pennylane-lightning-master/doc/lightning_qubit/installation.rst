.. include:: ../../README.rst
  :start-after:	installation_LQubit-start-inclusion-marker-do-not-remove
  :end-before: installation_LQubit-end-inclusion-marker-do-not-remove