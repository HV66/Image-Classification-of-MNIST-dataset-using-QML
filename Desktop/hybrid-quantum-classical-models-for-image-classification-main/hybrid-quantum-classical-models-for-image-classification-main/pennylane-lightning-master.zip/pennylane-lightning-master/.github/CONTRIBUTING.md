# Contributing to PennyLane-Lightning

Thank you for taking the time to contribute to PennyLane-Lightning!
:confetti_ball: :tada: :fireworks: :balloon:

For details on how to contribute, please see the [PennyLane contribution guide](https://github.com/PennyLaneAI/pennylane/blob/master/.github/CONTRIBUTING.md).


\- The PennyLane team
